Before Hydra was wiped out, Dr. Zola stored a secret in a Tree that is currently Unreachable. Steve has been trying search but is lost. Can you help him find it?
